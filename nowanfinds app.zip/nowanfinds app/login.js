function sendOTP(event) {
    event.preventDefault(); // Prevents form submission

    let phone = document.getElementById("phone").value.trim();
    
    if (phone === "") {
        document.getElementById("error-message").innerText = "Phone number is required.";
        return false;
    }

    // Simulating OTP send, then redirecting to OTP page
    window.location.href = "otp.html";
    return false;
}