document.addEventListener("DOMContentLoaded", function () {
    const searchButton = document.querySelector(".search-btn");

    searchButton.addEventListener("click", function () {
        const location = document.getElementById("location").value.trim();

        // Ensure location is entered
        if (location === "") {
            alert("Please enter a location.");
            return;
        }

        // Check if the location is "Bangalore"
        if (location.toLowerCase() === "bangalore") {
            window.location.href = "search-results.html"; // Redirect to search results page
        } else {
            alert("Currently unavailable at your location.");
        }
    });
});