function checkOtp(event) {
    event.preventDefault(); // Prevents form from refreshing the page

    let otp = document.getElementById("otp").value;
    let errorMessage = document.getElementById("error-message");

    if (otp === "0050") {
        // ✅ If OTP is correct, redirect to the home page (index.html)
        window.location.href = "index.html";
    } else {
        // ❌ If OTP is incorrect, show an error message
        errorMessage.innerText = "Invalid OTP. Please try again.";
        errorMessage.style.color = "red"; // Display error in red
    }
}